@echo off
cd /d "%~dp0"
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%~dp0Dark Macro.lnk'); $s.TargetPath = 'pythonw'; $s.Arguments = '\"%~dp0dark_macro.py\"'; $s.WorkingDirectory = '%~dp0'; $s.IconLocation = '%~dp0dark_macro_icon.ico'; $s.Description = 'Dark Macro'; $s.Save()"
echo تم إنشاء Dark Macro.lnk بنجاح!
timeout /t 2 >nul
