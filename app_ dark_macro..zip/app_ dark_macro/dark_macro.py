"""
Dark Macro v3.1 - أداة الماكرو الاحترافية
pip install customtkinter pyautogui pynput pillow pystray
"""

import customtkinter as ctk
import threading
import time
import json
import os
import sys
import subprocess
import pyautogui
from pynput import mouse, keyboard
from pynput.keyboard import Key, KeyCode, Listener as KbListener
from pynput.mouse import Button, Listener as MouseListener
import tkinter.messagebox as mb
import tkinter.filedialog as fd
from PIL import Image
import winreg

pyautogui.FAILSAFE = False

# ── إخفاء CMD ─────────────────────────────
if sys.platform == "win32":
    import ctypes
    try:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
    except:
        pass

# ── الألوان والخطوط ────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

PRIMARY    = "#7B2FBE"
ACCENT     = "#A855F7"
ACCENT2    = "#C084FC"
BG_DARK    = "#0A0A0F"
BG_CARD    = "#12121E"
BG_INPUT   = "#1A1A2E"
BG_HOVER   = "#1E1E35"
TEXT_MAIN  = "#F0EEFF"
TEXT_SUB   = "#7C7C9C"
SUCCESS    = "#22C55E"
DANGER     = "#EF4444"
SPOTIFY_G  = "#1DB954"

FONT_TITLE  = ("Segoe UI", 20, "bold")
FONT_HEAD   = ("Segoe UI", 13, "bold")
FONT_NORMAL = ("Segoe UI", 12)
FONT_SMALL  = ("Segoe UI", 10)
FONT_MICRO  = ("Segoe UI", 9)

SAVE_FILE   = "dark_macro_data.json"
APP_NAME    = "DarkMacro"
APP_REG_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"

# ── نظام اللغة ──────────────────────────────────
CURRENT_LANG = "ar"

STRINGS = {
    "ar": {
        "nav_macro":     "🎮  الماكرو",
        "nav_auto":      "🖱️  أوتو كليكر",
        "nav_rec":       "📽️  تسجيل",
        "nav_spotify":   "🎵  Spotify",
        "nav_settings":  "⚙️  الإعدادات",
        "version":       "v3.1  •  Dark Macro",
        "macro_title":   "🎮  إدارة الماكرو",
        "new_macro":     "+ ماكرو جديد",
        "no_macros":     "لا يوجد ماكرو حتى الآن\nاضغط '+ ماكرو جديد' لإنشاء واحد",
        "run":           "▶ تشغيل",
        "no_shortcut":   "بدون اختصار",
        "steps_count":   "خطوة",
        "delete_confirm":"تأكيد",
        "delete_msg":    "حذف",
        "ac_title":      "🖱️  أوتو كليكر",
        "ac_interval":   "الفاصل الزمني بين النقرات",
        "ac_hour":       "ساعة",
        "ac_min":        "دقيقة",
        "ac_sec":        "ثانية",
        "ac_ms":         "ملي ث",
        "ac_button":     "زر الماوس:",
        "ac_left":       "يسار",
        "ac_right":      "يمين",
        "ac_middle":     "وسط",
        "ac_click_type": "نوع النقر:",
        "ac_single":     "نقرة واحدة",
        "ac_double":     "نقرة مزدوجة",
        "ac_pos":        "الموضع:",
        "ac_current":    "مكان الماوس الحالي",
        "ac_coords":     "إحداثيات محددة",
        "ac_start":      "▶  تشغيل  (F6)",
        "ac_stop":       "⏹  إيقاف  (F6)",
        "ac_stopped":    "● متوقف",
        "ac_running":    "● يعمل الآن...",
        "rec_title":     "📽️  تسجيل الحركات",
        "rec_shortcuts": "اختصارات التسجيل",
        "rec_start_lbl": "بدء التسجيل:",
        "rec_stop_lbl":  "ايقاف التسجيل:",
        "rec_repeat":    "عدد التكرار:",
        "rec_infinite":  "(0 = لا نهاية)",
        "rec_begin":     "بدء التسجيل",
        "rec_stop_btn":  "ايقاف التسجيل",
        "rec_play":      "▶ تشغيل",
        "rec_clear":     "مسح",
        "rec_ready":     "● جاهز",
        "rec_recording": "● يسجّل الآن...",
        "rec_started":   "بدأ التسجيل...\n",
        "rec_ended":     "انتهى التسجيل.\n",
        "rec_events":    "● مسجّل {} حدث",
        "rec_pause_hint":"⚠️ حرّك الماوس لإيقاف مؤقت / توقف عن التحريك للاستمرار",
        "rec_paused":    "● متوقف مؤقتاً (حركة ماوس)...",
        "rec_resuming":  "● يعمل...",
        "rec_set":       "تعيين",
        "rec_unset":     "غير محدد",
        "rec_popup":     "تعيين اختصار",
        "rec_press":     "اضغط الاختصار المطلوب...",
        "rec_waiting":   "انتظار...",
        "key_lbl":       "مفتاح: {}\n",
        "set_title":     "⚙️  الإعدادات",
        "set_theme":     "وضع الإضاءة:",
        "set_theme_sw":  "غامق / فاتح",
        "set_startup":   "تشغيل مع بدء الويندوز:",
        "set_startup_d": "يضيف البرنامج لقائمة البرامج التي تبدأ مع الويندوز تلقائياً",
        "set_tray":      "System Tray",
        "set_tray_d":    "عند إغلاق النافذة، يظل البرنامج يعمل في شريط المهام.\nانقر على أيقونة Dark Macro في الـ Tray لإعادة فتحه.",
        "set_about_d":   "أداة ماكرو احترافية للاعبين والمستخدمين المتطورين.\nتدعم ذوي الاحتياجات الخاصة عبر اختصارات لوحة المفاتيح الكاملة.",
        "set_lang":      "اللغة / Language:",
        "ed_new":        "ماكرو جديد",
        "ed_edit":       "تعديل ماكرو",
        "ed_title_new":  "إنشاء ماكرو",
        "ed_title_edit": "تعديل ماكرو",
        "ed_name":       "اسم الماكرو",
        "ed_name_ph":    "مثال: تشغيل اللعبة",
        "ed_shortcut":   "اختصار لوحة المفاتيح",
        "ed_sc_hint":    "اضغط 'تسجيل' ثم اضغط الاختصار",
        "ed_sc_now":     "اضغط الاختصار الآن...",
        "ed_record":     "تسجيل",
        "ed_stop_rec":   "ايقاف",
        "ed_steps":      "خطوات الماكرو",
        "ed_open":       "فتح برنامج",
        "ed_delay":      "تأخير (ثانية)",
        "ed_key":        "ضغط مفتاح",
        "ed_val_ph":     "المسار / الثواني / الاختصار",
        "ed_add":        "+ إضافة",
        "ed_key_hint":   "ضغط مفتاح: ctrl+c  |  shift+a  |  f5  |  enter",
        "ed_save":       "حفظ الماكرو",
        "ed_warn_name":  "أدخل اسم الماكرو!",
        "ed_warn_steps": "أضف خطوة واحدة على الأقل!",
        "ed_warn_val":   "أدخل قيمة للخطوة!",
        "ed_browse":     "اختر البرنامج",
        "tray_open":     "فتح Dark Macro",
        "tray_close":    "إغلاق",
        "step_open":     "فتح برنامج",
        "step_delay":    "تأخير (ثانية)",
        "step_key":      "ضغط مفتاح",
        "sp_hotkeys":    "⌨️  اختصارات لوحة المفاتيح",
        "sp_prev":       "⏮  السابقة",
        "sp_pp":         "⏯  تشغيل/إيقاف",
        "sp_next":       "⏭  التالية",
        "sp_record":     "تسجيل",
        "sp_stop":       "⏹ إيقاف",
        "sp_unset":      "غير محدد",
        "sp_press":      "اضغط الاختصار...",
        "sp_hint":       "💡 اضغط 'تسجيل' ثم اضغط الكبسات اللي تبيها",
        "sp_launch":     "تشغيل Spotify",
        "sp_open_btn":   "▶  فتح Spotify",
        "sp_open_desc":  "يفتح تطبيق Spotify المثبت على جهازك",
        "sp_ctrl":       "التحكم بالتشغيل",
        "sp_playlist":   "فتح ألبوم / قائمة تشغيل",
        "sp_play_btn":   "▶ تشغيل",
        "sp_uri_hint":   "انسخ الـ URI من Spotify: كليك يمين على ألبوم/قائمة → Share → Copy Spotify URI",
    },
    "en": {
        "nav_macro":     "🎮  Macros",
        "nav_auto":      "🖱️  Auto Clicker",
        "nav_rec":       "📽️  Recorder",
        "nav_spotify":   "🎵  Spotify",
        "nav_settings":  "⚙️  Settings",
        "version":       "v3.1  •  Dark Macro",
        "macro_title":   "🎮  Manage Macros",
        "new_macro":     "+ New Macro",
        "no_macros":     "No macros yet\nPress '+ New Macro' to create one",
        "run":           "▶ Run",
        "no_shortcut":   "No shortcut",
        "steps_count":   "steps",
        "delete_confirm":"Confirm",
        "delete_msg":    "Delete",
        "ac_title":      "🖱️  Auto Clicker",
        "ac_interval":   "Click Interval",
        "ac_hour":       "hr",
        "ac_min":        "min",
        "ac_sec":        "sec",
        "ac_ms":         "ms",
        "ac_button":     "Mouse Button:",
        "ac_left":       "Left",
        "ac_right":      "Right",
        "ac_middle":     "Middle",
        "ac_click_type": "Click Type:",
        "ac_single":     "Single Click",
        "ac_double":     "Double Click",
        "ac_pos":        "Position:",
        "ac_current":    "Current Mouse Position",
        "ac_coords":     "Custom Coordinates",
        "ac_start":      "▶  Start  (F6)",
        "ac_stop":       "⏹  Stop  (F6)",
        "ac_stopped":    "● Stopped",
        "ac_running":    "● Running...",
        "rec_title":     "📽️  Motion Recorder",
        "rec_shortcuts": "Recording Shortcuts",
        "rec_start_lbl": "Start Recording:",
        "rec_stop_lbl":  "Stop Recording:",
        "rec_repeat":    "Repeat Count:",
        "rec_infinite":  "(0 = infinite)",
        "rec_begin":     "Start Recording",
        "rec_stop_btn":  "Stop Recording",
        "rec_play":      "▶ Play",
        "rec_clear":     "Clear",
        "rec_ready":     "● Ready",
        "rec_recording": "● Recording...",
        "rec_started":   "Recording started...\n",
        "rec_ended":     "Recording ended.\n",
        "rec_events":    "● Recorded {} events",
        "rec_pause_hint":"⚠️ Move mouse to pause / Stop moving to resume",
        "rec_paused":    "● Paused (mouse movement detected)...",
        "rec_resuming":  "● Running...",
        "rec_set":       "Set",
        "rec_unset":     "Not set",
        "rec_popup":     "Set Shortcut",
        "rec_press":     "Press the desired shortcut...",
        "rec_waiting":   "Waiting...",
        "key_lbl":       "Key: {}\n",
        "set_title":     "⚙️  Settings",
        "set_theme":     "Appearance:",
        "set_theme_sw":  "Dark / Light",
        "set_startup":   "Run on Windows startup:",
        "set_startup_d": "Adds the app to Windows startup programs automatically",
        "set_tray":      "System Tray",
        "set_tray_d":    "When the window is closed, the app stays running in the taskbar.\nClick the Dark Macro icon in the Tray to reopen it.",
        "set_about_d":   "Professional macro tool for gamers and power users.\nSupports accessibility via full keyboard shortcuts.",
        "set_lang":      "Language / اللغة:",
        "ed_new":        "New Macro",
        "ed_edit":       "Edit Macro",
        "ed_title_new":  "Create Macro",
        "ed_title_edit": "Edit Macro",
        "ed_name":       "Macro Name",
        "ed_name_ph":    "e.g. Launch Game",
        "ed_shortcut":   "Keyboard Shortcut",
        "ed_sc_hint":    "Press 'Record' then press the shortcut",
        "ed_sc_now":     "Press the shortcut now...",
        "ed_record":     "Record",
        "ed_stop_rec":   "Stop",
        "ed_steps":      "Macro Steps",
        "ed_open":       "Open Program",
        "ed_delay":      "Delay (seconds)",
        "ed_key":        "Press Key",
        "ed_val_ph":     "Path / Seconds / Shortcut",
        "ed_add":        "+ Add",
        "ed_key_hint":   "Key press: ctrl+c  |  shift+a  |  f5  |  enter",
        "ed_save":       "Save Macro",
        "ed_warn_name":  "Enter macro name!",
        "ed_warn_steps": "Add at least one step!",
        "ed_warn_val":   "Enter a value for the step!",
        "ed_browse":     "Choose Program",
        "tray_open":     "Open Dark Macro",
        "tray_close":    "Close",
        "step_open":     "Open Program",
        "step_delay":    "Delay (seconds)",
        "step_key":      "Press Key",
        "sp_hotkeys":    "⌨️  Keyboard Shortcuts",
        "sp_prev":       "⏮  Previous",
        "sp_pp":         "⏯  Play/Pause",
        "sp_next":       "⏭  Next",
        "sp_record":     "Record",
        "sp_stop":       "⏹ Stop",
        "sp_unset":      "Not set",
        "sp_press":      "Press shortcut...",
        "sp_hint":       "💡 Press 'Record' then press your desired keys",
        "sp_launch":     "Launch Spotify",
        "sp_open_btn":   "▶  Open Spotify",
        "sp_open_desc":  "Opens the Spotify app installed on your device",
        "sp_ctrl":       "Playback Controls",
        "sp_playlist":   "Open Album / Playlist",
        "sp_play_btn":   "▶ Play",
        "sp_uri_hint":   "Copy URI from Spotify: Right-click album/playlist → Share → Copy Spotify URI",
    }
}

def T(key):
    return STRINGS.get(CURRENT_LANG, STRINGS["ar"]).get(key, key)

# ── خريطة المفاتيح الخاصة ──────────────────
SPECIAL_KEYS = {
    "ctrl":Key.ctrl,"control":Key.ctrl,"shift":Key.shift,
    "alt":Key.alt,"win":Key.cmd,"super":Key.cmd,
    "enter":Key.enter,"return":Key.enter,"space":Key.space,
    "tab":Key.tab,"esc":Key.esc,"escape":Key.esc,
    "backspace":Key.backspace,"delete":Key.delete,"del":Key.delete,
    "up":Key.up,"down":Key.down,"left":Key.left,"right":Key.right,
    "home":Key.home,"end":Key.end,"pageup":Key.page_up,"pagedown":Key.page_down,
    "f1":Key.f1,"f2":Key.f2,"f3":Key.f3,"f4":Key.f4,
    "f5":Key.f5,"f6":Key.f6,"f7":Key.f7,"f8":Key.f8,
    "f9":Key.f9,"f10":Key.f10,"f11":Key.f11,"f12":Key.f12,
}

def parse_and_press_keys(combo: str):
    kc = keyboard.Controller()
    parts = [p.strip().lower() for p in combo.split("+")]
    keys = []
    for p in parts:
        if p in SPECIAL_KEYS: keys.append(SPECIAL_KEYS[p])
        elif len(p) == 1: keys.append(p)
        else: keys.append(p)
    for k in keys:
        try: kc.press(k)
        except: pass
    time.sleep(0.05)
    for k in reversed(keys):
        try: kc.release(k)
        except: pass

def key_to_str(key) -> str:
    if hasattr(key, "char") and key.char:
        return key.char.upper()
    return str(key).replace("Key.", "").upper()


# ─────────────────────────────────────────────
#  نافذة إنشاء / تعديل ماكرو
# ─────────────────────────────────────────────
class MacroEditorWindow(ctk.CTkToplevel):
    def __init__(self, master, on_save, existing=None):
        super().__init__(master)
        self.title(T("ed_title_new") if not existing else T("ed_title_edit"))
        self.geometry("560x700")
        self.resizable(False, False)
        self.configure(fg_color=BG_DARK)
        try:
            _base = os.path.dirname(os.path.abspath(__file__))
            _ico  = os.path.join(_base, "dark_macro_icon.ico")
            if os.path.exists(_ico):
                self.after(200, lambda: self.iconbitmap(_ico))
        except:
            pass
        self.on_save = on_save
        self.steps = existing["steps"][:] if existing else []
        self.shortcut_keys_list = []
        self.shortcut_keys_set  = set()
        self.recording_shortcut = False
        self._kb_listener = None
        self._build_ui(existing)

    def _build_ui(self, existing):
        pad = {"padx": 22, "pady": 7}
        title = T("ed_edit") if existing else T("ed_new")
        base      = os.path.dirname(os.path.abspath(__file__))
        logo_path = os.path.join(base, "dark_macro_logo.png")
        self._editor_logo_ref = None
        top_row = ctk.CTkFrame(self, fg_color="transparent")
        top_row.pack(fill="x", padx=22, pady=(14, 4))
        if os.path.exists(logo_path):
            try:
                _pil = Image.open(logo_path).convert("RGBA")
                self._editor_logo_ref = ctk.CTkImage(
                    light_image=_pil, dark_image=_pil, size=(56, 56))
                ctk.CTkLabel(top_row, image=self._editor_logo_ref,
                             text="").pack(side="left", padx=(0, 10))
            except Exception as _e:
                print(f"editor logo error: {_e}")
        ctk.CTkLabel(top_row, text=title, font=FONT_TITLE,
                     text_color=ACCENT2).pack(side="left", anchor="s", pady=(0, 6))

        ctk.CTkLabel(self, text=T("ed_name"), font=FONT_HEAD,
                     text_color=TEXT_SUB).pack(anchor="w", **pad)
        self.name_entry = ctk.CTkEntry(self, placeholder_text=T("ed_name_ph"),
                                       fg_color=BG_INPUT, border_color=PRIMARY,
                                       font=FONT_NORMAL, height=40, corner_radius=10)
        self.name_entry.pack(fill="x", **pad)
        if existing: self.name_entry.insert(0, existing["name"])

        ctk.CTkLabel(self, text=T("ed_shortcut"), font=FONT_HEAD,
                     text_color=TEXT_SUB).pack(anchor="w", **pad)
        sc_frame = ctk.CTkFrame(self, fg_color=BG_CARD, corner_radius=10,
                                border_width=1, border_color=PRIMARY)
        sc_frame.pack(fill="x", **pad)
        saved_sc = existing["shortcut"] if existing else ""
        self.shortcut_label = ctk.CTkLabel(sc_frame,
            text=saved_sc if saved_sc else T("ed_sc_hint"),
            font=FONT_NORMAL, text_color=TEXT_MAIN)
        self.shortcut_label.pack(side="left", padx=12, pady=10)
        self.record_btn = ctk.CTkButton(sc_frame, text=T("ed_record"),
            fg_color=PRIMARY, hover_color=ACCENT, font=FONT_NORMAL,
            width=110, height=36, corner_radius=8,
            command=self._toggle_shortcut_record)
        self.record_btn.pack(side="right", padx=10, pady=8)

        ctk.CTkLabel(self, text=T("ed_steps"), font=FONT_HEAD,
                     text_color=TEXT_SUB).pack(anchor="w", **pad)
        self.steps_frame = ctk.CTkScrollableFrame(self, fg_color=BG_CARD,
                                                   height=150, corner_radius=10)
        self.steps_frame.pack(fill="x", **pad)
        self._refresh_steps()

        add_frame = ctk.CTkFrame(self, fg_color=BG_CARD, corner_radius=10)
        add_frame.pack(fill="x", **pad)
        self.step_type = ctk.CTkComboBox(add_frame,
            values=[T("ed_open"), T("ed_delay"), T("ed_key")],
            fg_color=BG_INPUT, font=FONT_NORMAL, width=160,
            command=self._on_type_change)
        self.step_type.pack(side="left", padx=10, pady=10)
        self.step_value = ctk.CTkEntry(add_frame,
            placeholder_text=T("ed_val_ph"),
            fg_color=BG_INPUT, font=FONT_NORMAL, corner_radius=8)
        self.step_value.pack(side="left", fill="x", expand=True, padx=4)
        ctk.CTkButton(add_frame, text="📂", fg_color=BG_INPUT,
            hover_color=PRIMARY, font=FONT_NORMAL, width=36,
            command=self._browse_file).pack(side="left", padx=4)
        ctk.CTkButton(add_frame, text=T("ed_add"),
            fg_color=PRIMARY, hover_color=ACCENT, font=FONT_NORMAL,
            width=90, corner_radius=8,
            command=self._add_step).pack(side="right", padx=10, pady=10)

        ctk.CTkLabel(self, text=T("ed_key_hint"),
                     font=FONT_MICRO, text_color=TEXT_SUB).pack(anchor="w", padx=22)

        ctk.CTkButton(self, text=T("ed_save"),
            fg_color=PRIMARY, hover_color=ACCENT,
            font=FONT_HEAD, height=44, corner_radius=12,
            command=self._save).pack(fill="x", padx=22, pady=14)

    def _on_type_change(self, val): self.step_value.delete(0, "end")

    def _browse_file(self):
        path = fd.askopenfilename(title=T("ed_browse"),
                                   filetypes=[("Programs","*.exe"),("All","*.*")])
        if path:
            self.step_value.delete(0, "end")
            self.step_value.insert(0, path)

    def _add_step(self):
        t = self.step_type.get()
        v = self.step_value.get().strip()
        if not v:
            mb.showwarning(T("delete_confirm"), T("ed_warn_val"), parent=self)
            return
        self.steps.append({"type": t, "value": v})
        self.step_value.delete(0, "end")
        self._refresh_steps()

    def _refresh_steps(self):
        for w in self.steps_frame.winfo_children(): w.destroy()
        step_open_labels  = [T("ed_open"),  "فتح برنامج",  "Open Program"]
        step_delay_labels = [T("ed_delay"), "تأخير (ثانية)", "Delay (seconds)"]
        step_key_labels   = [T("ed_key"),   "ضغط مفتاح",  "Press Key"]
        for i, s in enumerate(self.steps):
            row = ctk.CTkFrame(self.steps_frame, fg_color=BG_INPUT, corner_radius=8)
            row.pack(fill="x", padx=4, pady=3)
            t = s["type"]
            if t in step_open_labels:  icon = "🚀"
            elif t in step_delay_labels: icon = "⏳"
            elif t in step_key_labels:  icon = "⌨️"
            else: icon = "•"
            ctk.CTkLabel(row, text=f"{i+1}. {icon} {s['type']}: {s['value']}",
                         font=FONT_SMALL, text_color=TEXT_MAIN,
                         anchor="w").pack(side="left", padx=8, fill="x", expand=True)
            ctk.CTkButton(row, text="🗑", fg_color="transparent",
                text_color=DANGER, hover_color=BG_CARD,
                font=FONT_SMALL, width=30,
                command=lambda x=i: self._remove_step(x)).pack(side="right", padx=4)

    def _remove_step(self, idx):
        self.steps.pop(idx)
        self._refresh_steps()

    def _toggle_shortcut_record(self):
        if not self.recording_shortcut:
            self.recording_shortcut = True
            self.shortcut_keys_list = []
            self.shortcut_keys_set  = set()
            self.record_btn.configure(text=T("ed_stop_rec"), fg_color=DANGER)
            self.shortcut_label.configure(text=T("ed_sc_now"))
            self._kb_listener = KbListener(
                on_press=self._on_sc_press,
                on_release=self._on_sc_release)
            self._kb_listener.start()
        else:
            self._stop_shortcut_record()

    def _on_sc_press(self, key):
        name = key_to_str(key)
        if name not in self.shortcut_keys_set:
            self.shortcut_keys_set.add(name)
            self.shortcut_keys_list.append(name)
        self.shortcut_label.configure(text="+".join(self.shortcut_keys_list))

    def _on_sc_release(self, key):
        self.after(100, self._stop_shortcut_record)

    def _stop_shortcut_record(self):
        if not self.recording_shortcut: return
        self.recording_shortcut = False
        if self._kb_listener:
            self._kb_listener.stop()
            self._kb_listener = None
        self.record_btn.configure(text=T("ed_record"), fg_color=PRIMARY)

    def _save(self):
        name = self.name_entry.get().strip()
        shortcut = self.shortcut_label.cget("text")
        if shortcut in (T("ed_sc_hint"), T("ed_sc_now")):
            shortcut = ""
        if not name:
            mb.showwarning(T("delete_confirm"), T("ed_warn_name"), parent=self)
            return
        if not self.steps:
            mb.showwarning(T("delete_confirm"), T("ed_warn_steps"), parent=self)
            return
        self._stop_shortcut_record()
        self.on_save({"name": name, "shortcut": shortcut, "steps": self.steps})
        self.destroy()


# ─────────────────────────────────────────────
#  التطبيق الرئيسي
# ─────────────────────────────────────────────
class DarkMacroApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Dark Macro v3.1")
        self.geometry("960x660")
        self.minsize(820, 580)
        self.configure(fg_color=BG_DARK)

        self._set_icon()

        self.macros = []
        self.auto_click_running = False
        self.record_running     = False
        self.recorded_events    = []
        self._pressed_keys      = set()
        self._hotkey_lock       = threading.Lock()
        self.rec_start_hotkey   = ""
        self.rec_stop_hotkey    = ""
        self.spotify_prev_hotkey = ""
        self.spotify_next_hotkey = ""
        self.spotify_pp_hotkey   = ""
        self._running_macros    = {}   # id(macro) -> threading.Event

        self._load_data()
        self._build_ui()
        self._start_global_hotkeys()

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._tray_icon = None
        threading.Thread(target=self._setup_tray, daemon=True).start()

    # ── أيقونة محسّنة ──────────────────────────
    def _set_icon(self):
        base      = os.path.dirname(os.path.abspath(__file__))
        ico_path  = os.path.join(base, "dark_macro_icon.ico")
        logo_path = os.path.join(base, "dark_macro_logo.png")
        try:
            if os.path.exists(ico_path):
                self.iconbitmap(default=ico_path)
                # أيضاً نضبط لـ taskbar على Windows
                if sys.platform == "win32":
                    import ctypes
                    myappid = 'darkmacro.app.v31'
                    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
                return
            if os.path.exists(logo_path):
                from PIL import Image as PILImage
                img = PILImage.open(logo_path).convert("RGBA")
                sizes = [256, 128, 64, 48, 32, 16]
                imgs  = [img.resize((s, s), PILImage.LANCZOS) for s in sizes]
                imgs[0].save(ico_path, format="ICO",
                             sizes=[(s, s) for s in sizes],
                             append_images=imgs[1:])
                self.iconbitmap(default=ico_path)
                if sys.platform == "win32":
                    import ctypes
                    myappid = 'darkmacro.app.v31'
                    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        except Exception as e:
            print(f"icon error: {e}")

    def _setup_tray(self):
        try:
            import pystray
            from PIL import Image as PILImage
            logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dark_macro_logo.png")
            if os.path.exists(logo_path):
                tray_img = PILImage.open(logo_path).resize((64, 64), PILImage.LANCZOS)
            else:
                tray_img = PILImage.new("RGB", (64, 64), color=(123, 47, 190))
            menu = pystray.Menu(
                pystray.MenuItem(T("tray_open"), self._show_from_tray, default=True),
                pystray.MenuItem(T("tray_close"), self._quit_app)
            )
            self._tray_icon = pystray.Icon("DarkMacro", tray_img, "Dark Macro v3.1", menu)
            self._tray_icon.run_detached()
        except ImportError:
            pass

    def _on_close(self):
        self.withdraw()

    def _show_from_tray(self, icon=None, item=None):
        self.after(0, self.deiconify)
        self.after(0, self.lift)

    def _quit_app(self, icon=None, item=None):
        if self._tray_icon:
            try: self._tray_icon.stop()
            except: pass
        self.after(0, self.destroy)

    # ─── بناء الواجهة ─────────────────────────
    def _build_ui(self):
        # حذف القديم لو موجود (عند إعادة البناء عند تغيير اللغة)
        for widget in self.winfo_children():
            widget.destroy()

        sidebar = ctk.CTkFrame(self, fg_color=BG_CARD, width=215, corner_radius=0)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        base      = os.path.dirname(os.path.abspath(__file__))
        logo_path = os.path.join(base, "dark_macro_logo.png")
        self._sidebar_logo_ref = None
        if os.path.exists(logo_path):
            try:
                _pil_logo = Image.open(logo_path).convert("RGBA")
                self._sidebar_logo_ref = ctk.CTkImage(
                    light_image=_pil_logo, dark_image=_pil_logo, size=(120, 120))
                ctk.CTkLabel(sidebar, image=self._sidebar_logo_ref,
                             text="").pack(pady=(14, 4))
            except:
                ctk.CTkLabel(sidebar, text="Dark Macro",
                             font=FONT_TITLE, text_color=ACCENT).pack(pady=26)
        else:
            ctk.CTkLabel(sidebar, text="Dark Macro",
                         font=FONT_TITLE, text_color=ACCENT).pack(pady=26)

        ctk.CTkFrame(sidebar, height=1, fg_color=PRIMARY).pack(fill="x", padx=16, pady=(0, 10))

        nav_items = [
            (T("nav_macro"),    "macro",    self._show_macro),
            (T("nav_auto"),     "auto",     self._show_autoclicker),
            (T("nav_rec"),      "rec",      self._show_recorder),
            (T("nav_spotify"),  "spotify",  self._show_spotify),
            (T("nav_settings"), "settings", self._show_settings),
        ]
        self.nav_btns = {}
        for label, key, cmd in nav_items:
            btn = ctk.CTkButton(sidebar, text=label, font=FONT_NORMAL,
                fg_color="transparent", text_color=TEXT_SUB,
                hover_color=BG_HOVER, height=42, anchor="w", corner_radius=10,
                command=lambda k=key, c=cmd: (c(), self._set_active_nav(k)))
            btn.pack(fill="x", padx=10, pady=2)
            self.nav_btns[key] = btn

        ctk.CTkLabel(sidebar, text=T("version"),
                     font=FONT_MICRO, text_color=TEXT_SUB).pack(side="bottom", pady=14)

        self.main_area = ctk.CTkFrame(self, fg_color=BG_DARK, corner_radius=0)
        self.main_area.pack(side="right", fill="both", expand=True)

        self.frames = {}
        self._build_macro_frame()
        self._build_autoclicker_frame()
        self._build_recorder_frame()
        self._build_spotify_frame()
        self._build_settings_frame()
        self._show_macro()
        self._set_active_nav("macro")

    def _set_active_nav(self, active_key):
        for key, btn in self.nav_btns.items():
            if key == active_key:
                btn.configure(fg_color=PRIMARY, text_color=TEXT_MAIN)
            else:
                btn.configure(fg_color="transparent", text_color=TEXT_SUB)

    def _clear_main(self):
        for f in self.frames.values(): f.pack_forget()

    def _show_macro(self):
        self._clear_main()
        self.frames["macro"].pack(fill="both", expand=True, padx=26, pady=26)

    def _show_autoclicker(self):
        self._clear_main()
        self.frames["auto"].pack(fill="both", expand=True, padx=26, pady=26)

    def _show_recorder(self):
        self._clear_main()
        self.frames["rec"].pack(fill="both", expand=True, padx=26, pady=26)

    def _show_spotify(self):
        self._clear_main()
        self.frames["spotify"].pack(fill="both", expand=True, padx=26, pady=26)

    def _show_settings(self):
        self._clear_main()
        self.frames["settings"].pack(fill="both", expand=True, padx=26, pady=26)

    # ─── تبويب الماكرو ─────────────────────────
    def _build_macro_frame(self):
        f = ctk.CTkFrame(self.main_area, fg_color="transparent")
        self.frames["macro"] = f

        header = ctk.CTkFrame(f, fg_color="transparent")
        header.pack(fill="x", pady=(0, 16))
        ctk.CTkLabel(header, text=T("macro_title"),
                     font=FONT_TITLE, text_color=TEXT_MAIN).pack(side="left")
        ctk.CTkButton(header, text=T("new_macro"),
            fg_color=PRIMARY, hover_color=ACCENT,
            font=FONT_NORMAL, width=150, height=38, corner_radius=10,
            command=self._new_macro).pack(side="right")

        self.macro_list_frame = ctk.CTkScrollableFrame(f, fg_color=BG_CARD, corner_radius=14)
        self.macro_list_frame.pack(fill="both", expand=True)
        self._refresh_macro_list()

    def _refresh_macro_list(self):
        for w in self.macro_list_frame.winfo_children(): w.destroy()
        if not self.macros:
            ctk.CTkLabel(self.macro_list_frame,
                         text=T("no_macros"),
                         font=FONT_NORMAL, text_color=TEXT_SUB,
                         justify="center").pack(expand=True, pady=60)
            return
        for i, m in enumerate(self.macros):
            card = ctk.CTkFrame(self.macro_list_frame, fg_color=BG_INPUT,
                                corner_radius=12, border_width=1, border_color=BG_HOVER)
            card.pack(fill="x", padx=10, pady=5)
            left = ctk.CTkFrame(card, fg_color="transparent")
            left.pack(side="left", fill="x", expand=True, padx=14, pady=10)
            ctk.CTkLabel(left, text=f"🚀  {m['name']}",
                         font=FONT_HEAD, text_color=TEXT_MAIN, anchor="w").pack(anchor="w")
            sc = f"⌨️  {m['shortcut']}" if m.get("shortcut") else T("no_shortcut")
            ctk.CTkLabel(left, text=sc, font=FONT_SMALL,
                         text_color=ACCENT2, anchor="w").pack(anchor="w")
            ctk.CTkLabel(left, text=f"{len(m['steps'])} {T('steps_count')}",
                         font=FONT_MICRO, text_color=TEXT_SUB, anchor="w").pack(anchor="w")

            btn_f = ctk.CTkFrame(card, fg_color="transparent")
            btn_f.pack(side="right", padx=12, pady=10)
            ctk.CTkButton(btn_f, text=T("run"),
                fg_color=SUCCESS, hover_color="#16A34A",
                font=FONT_SMALL, height=34, width=80, corner_radius=8,
                command=lambda x=i: threading.Thread(
                    target=self._run_macro, args=(x,), daemon=True).start()
            ).pack(side="left", padx=4)
            ctk.CTkButton(btn_f, text="✏️",
                fg_color=BG_CARD, hover_color=PRIMARY,
                font=FONT_SMALL, height=34, width=38, corner_radius=8,
                command=lambda x=i: self._edit_macro(x)).pack(side="left", padx=2)
            ctk.CTkButton(btn_f, text="🗑",
                fg_color=BG_CARD, hover_color=DANGER,
                font=FONT_SMALL, height=34, width=38, corner_radius=8,
                command=lambda x=i: self._delete_macro(x)).pack(side="left", padx=2)

    def _new_macro(self):
        MacroEditorWindow(self, self._add_macro)

    def _add_macro(self, macro):
        self.macros.append(macro)
        self._save_data()
        self._refresh_macro_list()

    def _edit_macro(self, idx):
        def on_save(updated):
            self.macros[idx] = updated
            self._save_data()
            self._refresh_macro_list()
        MacroEditorWindow(self, on_save, existing=self.macros[idx])

    def _delete_macro(self, idx):
        if mb.askyesno(T("delete_confirm"), f"{T('delete_msg')} '{self.macros[idx]['name']}'?"):
            # أوقف الماكرو لو كان شغال
            macro_id = id(self.macros[idx])
            if macro_id in self._running_macros:
                self._running_macros[macro_id].set()  # signal للإيقاف
            self.macros.pop(idx)
            self._save_data()
            self._refresh_macro_list()

    def _run_macro(self, idx):
        if idx >= len(self.macros):
            return
        m = self.macros[idx]
        macro_id = id(m)

        # لو نفس الماكرو شغال بالفعل، ما نشغله مرتين
        if macro_id in self._running_macros and not self._running_macros[macro_id].is_set():
            return

        stop_event = threading.Event()
        self._running_macros[macro_id] = stop_event

        open_labels  = ["فتح برنامج", "Open Program", T("ed_open")]
        delay_labels = ["تأخير (ثانية)", "Delay (seconds)", T("ed_delay")]
        key_labels   = ["ضغط مفتاح", "Press Key", T("ed_key")]

        for s in m["steps"]:
            if stop_event.is_set():
                break
            t, v = s["type"], s["value"]
            try:
                if t in open_labels:
                    subprocess.Popen(v, shell=True)
                    # انتظر 0.5 ث مع فحص الإيقاف
                    stop_event.wait(0.5)
                elif t in delay_labels:
                    stop_event.wait(float(v))
                elif t in key_labels:
                    if not stop_event.is_set():
                        parse_and_press_keys(v)
            except Exception as e:
                print(f"خطأ [{t}={v}]: {e}")

        # نظّف بعد الانتهاء
        self._running_macros.pop(macro_id, None)

    # ─── تبويب أوتو كليكر ──────────────────────
    def _build_autoclicker_frame(self):
        f = ctk.CTkFrame(self.main_area, fg_color="transparent")
        self.frames["auto"] = f

        ctk.CTkLabel(f, text=T("ac_title"),
                     font=FONT_TITLE, text_color=TEXT_MAIN).pack(anchor="w", pady=(0, 18))

        card = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                            border_width=1, border_color=BG_HOVER)
        card.pack(fill="x")

        ctk.CTkLabel(card, text=T("ac_interval"),
                     font=FONT_HEAD, text_color=ACCENT).pack(anchor="w", padx=20, pady=(16, 6))

        time_row = ctk.CTkFrame(card, fg_color="transparent")
        time_row.pack(fill="x", padx=20, pady=4)

        def _lbl(p, t):
            ctk.CTkLabel(p, text=t, font=FONT_SMALL, text_color=TEXT_SUB, width=40).pack(side="left")
        def _entry(p, d, w=64):
            sv = ctk.StringVar(value=d)
            ctk.CTkEntry(p, textvariable=sv, fg_color=BG_INPUT, font=FONT_NORMAL,
                         width=w, justify="center", corner_radius=8).pack(side="left", padx=4)
            return sv

        _lbl(time_row, T("ac_hour"));   self.t_hours   = _entry(time_row, "0")
        _lbl(time_row, T("ac_min"));    self.t_minutes = _entry(time_row, "0")
        _lbl(time_row, T("ac_sec"));    self.t_seconds = _entry(time_row, "0")
        _lbl(time_row, T("ac_ms"));     self.t_ms      = _entry(time_row, "100")

        row2 = ctk.CTkFrame(card, fg_color="transparent")
        row2.pack(fill="x", padx=20, pady=8)
        ctk.CTkLabel(row2, text=T("ac_button"), font=FONT_NORMAL,
                     text_color=TEXT_MAIN, width=130, anchor="w").pack(side="left")
        self.mouse_btn = ctk.CTkComboBox(row2, values=[T("ac_left"),T("ac_right"),T("ac_middle")],
            fg_color=BG_INPUT, font=FONT_NORMAL, width=150, corner_radius=8)
        self.mouse_btn.pack(side="left")

        row_click = ctk.CTkFrame(card, fg_color="transparent")
        row_click.pack(fill="x", padx=20, pady=8)
        ctk.CTkLabel(row_click, text=T("ac_click_type"), font=FONT_NORMAL,
                     text_color=TEXT_MAIN, width=130, anchor="w").pack(side="left")
        self.click_type = ctk.CTkComboBox(row_click, values=[T("ac_single"),T("ac_double")],
            fg_color=BG_INPUT, font=FONT_NORMAL, width=150, corner_radius=8)
        self.click_type.pack(side="left")

        row3 = ctk.CTkFrame(card, fg_color="transparent")
        row3.pack(fill="x", padx=20, pady=8)
        ctk.CTkLabel(row3, text=T("ac_pos"), font=FONT_NORMAL,
                     text_color=TEXT_MAIN, width=130, anchor="w").pack(side="left")
        self.pos_mode = ctk.CTkComboBox(row3,
            values=[T("ac_current"),T("ac_coords")],
            fg_color=BG_INPUT, font=FONT_NORMAL, width=200, corner_radius=8,
            command=self._on_pos_mode)
        self.pos_mode.pack(side="left")

        self.coords_frame = ctk.CTkFrame(card, fg_color="transparent")
        self.coords_frame.pack(fill="x", padx=20, pady=4)
        ctk.CTkLabel(self.coords_frame, text="X:", font=FONT_NORMAL,
                     text_color=TEXT_MAIN).pack(side="left")
        self.x_entry = ctk.CTkEntry(self.coords_frame, fg_color=BG_INPUT,
                                    font=FONT_NORMAL, width=80, corner_radius=8)
        self.x_entry.pack(side="left", padx=4)
        ctk.CTkLabel(self.coords_frame, text="Y:", font=FONT_NORMAL,
                     text_color=TEXT_MAIN).pack(side="left", padx=(10,0))
        self.y_entry = ctk.CTkEntry(self.coords_frame, fg_color=BG_INPUT,
                                    font=FONT_NORMAL, width=80, corner_radius=8)
        self.y_entry.pack(side="left", padx=4)
        self.coords_frame.pack_forget()

        btn_row = ctk.CTkFrame(card, fg_color="transparent")
        btn_row.pack(fill="x", padx=20, pady=16)
        self.ac_start_btn = ctk.CTkButton(btn_row, text=T("ac_start"),
            fg_color=SUCCESS, hover_color="#16A34A",
            font=FONT_HEAD, height=46, corner_radius=12,
            command=self._toggle_autoclicker)
        self.ac_start_btn.pack(fill="x")

        self.ac_status = ctk.CTkLabel(f, text=T("ac_stopped"),
                                      font=FONT_NORMAL, text_color=TEXT_SUB)
        self.ac_status.pack(anchor="w", padx=4, pady=8)

    def _on_pos_mode(self, val):
        if val == T("ac_coords"): self.coords_frame.pack(fill="x", padx=20, pady=4)
        else: self.coords_frame.pack_forget()

    def _get_interval(self) -> float:
        try:
            h  = int(self.t_hours.get()   or 0)
            m  = int(self.t_minutes.get() or 0)
            s  = int(self.t_seconds.get() or 0)
            ms = int(self.t_ms.get()      or 100)
            return max(0.001, h*3600 + m*60 + s + ms/1000.0)
        except: return 0.1

    def _toggle_autoclicker(self):
        if not self.auto_click_running:
            self.auto_click_running = True
            self.ac_start_btn.configure(text=T("ac_stop"),
                                        fg_color=DANGER, hover_color="#B91C1C")
            self.ac_status.configure(text=T("ac_running"), text_color=SUCCESS)
            threading.Thread(target=self._autoclicker_loop, daemon=True).start()
        else:
            self.auto_click_running = False
            self.ac_start_btn.configure(text=T("ac_start"),
                                        fg_color=SUCCESS, hover_color="#16A34A")
            self.ac_status.configure(text=T("ac_stopped"), text_color=TEXT_SUB)

    def _autoclicker_loop(self):
        mc = mouse.Controller()
        while self.auto_click_running:
            interval = self._get_interval()
            btn_val = self.mouse_btn.get()
            if btn_val in [T("ac_right"), "يمين", "Right"]:
                btn = Button.right
            elif btn_val in [T("ac_middle"), "وسط", "Middle"]:
                btn = Button.middle
            else:
                btn = Button.left
            click_val = self.click_type.get()
            count = 2 if click_val in ["نقرة مزدوجة", "Double Click", T("ac_double")] else 1
            pos_val = self.pos_mode.get()
            if pos_val in ["إحداثيات محددة", "Custom Coordinates", T("ac_coords")]:
                try: mc.position = (int(self.x_entry.get()), int(self.y_entry.get()))
                except: pass
            mc.click(btn, count)
            time.sleep(interval)

    # ─── تبويب التسجيل ─────────────────────────
    def _build_recorder_frame(self):
        f = ctk.CTkFrame(self.main_area, fg_color="transparent")
        self.frames["rec"] = f

        ctk.CTkLabel(f, text=T("rec_title"),
                     font=FONT_TITLE, text_color=TEXT_MAIN).pack(anchor="w", pady=(0, 12))

        hk_card = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                               border_width=1, border_color=BG_HOVER)
        hk_card.pack(fill="x", pady=(0, 10))

        ctk.CTkLabel(hk_card, text=T("rec_shortcuts"),
                     font=FONT_HEAD, text_color=ACCENT).pack(anchor="w", padx=18, pady=(12, 4))

        for which, attr, lbl_attr, label_txt in [
            ("start", "rec_start_hotkey", "rec_start_lbl", T("rec_start_lbl")),
            ("stop",  "rec_stop_hotkey",  "rec_stop_lbl",  T("rec_stop_lbl")),
        ]:
            row = ctk.CTkFrame(hk_card, fg_color="transparent")
            row.pack(fill="x", padx=18, pady=4)
            ctk.CTkLabel(row, text=label_txt, font=FONT_NORMAL,
                         text_color=TEXT_MAIN, width=140, anchor="w").pack(side="left")
            current_val = getattr(self, attr)
            lbl = ctk.CTkLabel(row,
                text=current_val if current_val else T("rec_unset"),
                font=FONT_NORMAL, text_color=ACCENT2,
                fg_color=BG_INPUT, corner_radius=8, width=130)
            lbl.pack(side="left", padx=6, ipady=4)
            setattr(self, lbl_attr, lbl)
            ctk.CTkButton(row, text=T("rec_set"), fg_color=PRIMARY, hover_color=ACCENT,
                font=FONT_SMALL, width=70, height=32, corner_radius=8,
                command=lambda w=which: self._capture_hotkey(w)).pack(side="left", padx=6)

        rep_row = ctk.CTkFrame(hk_card, fg_color="transparent")
        rep_row.pack(fill="x", padx=18, pady=(4, 14))
        ctk.CTkLabel(rep_row, text=T("rec_repeat"), font=FONT_NORMAL,
                     text_color=TEXT_MAIN, width=140, anchor="w").pack(side="left")
        self.rec_repeat_var = ctk.StringVar(value="1")
        ctk.CTkEntry(rep_row, textvariable=self.rec_repeat_var,
                     fg_color=BG_INPUT, font=FONT_NORMAL,
                     width=70, justify="center", corner_radius=8).pack(side="left", padx=6)
        ctk.CTkLabel(rep_row, text=T("rec_infinite"), font=FONT_SMALL,
                     text_color=TEXT_SUB).pack(side="left", padx=6)

        ctrl_card = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                                 border_width=1, border_color=BG_HOVER)
        ctrl_card.pack(fill="x", pady=(0, 10))

        btn_row = ctk.CTkFrame(ctrl_card, fg_color="transparent")
        btn_row.pack(fill="x", padx=18, pady=14)
        self.rec_btn = ctk.CTkButton(btn_row, text=T("rec_begin"),
            fg_color=DANGER, hover_color="#B91C1C",
            font=FONT_HEAD, height=44, width=200, corner_radius=10,
            command=self._toggle_record)
        self.rec_btn.pack(side="left", padx=(0, 8))
        self.play_rec_btn = ctk.CTkButton(btn_row, text=T("rec_play"),
            fg_color=SUCCESS, hover_color="#16A34A",
            font=FONT_HEAD, height=44, width=140, corner_radius=10,
            command=self._play_recording, state="disabled")
        self.play_rec_btn.pack(side="left", padx=(0, 8))
        ctk.CTkButton(btn_row, text=T("rec_clear"),
            fg_color=BG_INPUT, hover_color=DANGER,
            font=FONT_NORMAL, height=44, width=80, corner_radius=10,
            command=self._clear_recording).pack(side="right")

        self.rec_log = ctk.CTkTextbox(f, fg_color=BG_CARD, font=FONT_SMALL,
                                      text_color=TEXT_MAIN, corner_radius=12, state="disabled")
        self.rec_log.pack(fill="both", expand=True, pady=(4, 0))

        ctk.CTkLabel(f, text=T("rec_pause_hint"),
                     font=FONT_MICRO, text_color=ACCENT2).pack(anchor="w", pady=(2,0))

        self.rec_status = ctk.CTkLabel(f, text=T("rec_ready"),
                                       font=FONT_NORMAL, text_color=TEXT_SUB)
        self.rec_status.pack(anchor="w", pady=6)

    def _capture_hotkey(self, which):
        popup = ctk.CTkToplevel(self)
        popup.title(T("rec_popup"))
        popup.geometry("300x130")
        popup.configure(fg_color=BG_DARK)
        popup.resizable(False, False)
        ctk.CTkLabel(popup, text=T("rec_press"),
                     font=FONT_HEAD, text_color=TEXT_MAIN).pack(pady=20)
        lbl = ctk.CTkLabel(popup, text=T("rec_waiting"),
                           font=FONT_NORMAL, text_color=ACCENT2)
        lbl.pack()
        captured = []

        def on_press(key):
            name = key_to_str(key)
            if name not in captured: captured.append(name)
            lbl.configure(text="+".join(captured))

        def on_release(key):
            if captured:
                combo = "+".join(captured)
                if which == "start":
                    self.rec_start_hotkey = combo
                    self.rec_start_lbl.configure(text=combo)
                else:
                    self.rec_stop_hotkey = combo
                    self.rec_stop_lbl.configure(text=combo)
                self._save_data()
                listener.stop()
                popup.after(200, popup.destroy)

        listener = KbListener(on_press=on_press, on_release=on_release)
        listener.start()

    def _toggle_record(self):
        if not self.record_running:
            self.record_running = True
            self.recorded_events = []
            self._rec_start_time = time.time()
            self.rec_btn.configure(text=T("rec_stop_btn"), fg_color=PRIMARY)
            self.rec_status.configure(text=T("rec_recording"), text_color=DANGER)
            self.play_rec_btn.configure(state="disabled")
            self._log_rec(T("rec_started"))
            threading.Thread(target=self._start_listeners, daemon=True).start()
        else:
            self._stop_recording()

    def _stop_recording(self):
        self.record_running = False
        self.rec_btn.configure(text=T("rec_begin"), fg_color=DANGER)
        self.rec_status.configure(
            text=T("rec_events").format(len(self.recorded_events)), text_color=SUCCESS)
        if self.recorded_events:
            self.play_rec_btn.configure(state="normal")
        self._log_rec(T("rec_ended"))

    def _start_listeners(self):
        def on_move(x, y):
            if self.record_running:
                t = time.time() - self._rec_start_time
                self.recorded_events.append(("move", x, y, t))
        def on_click(x, y, button, pressed):
            if self.record_running:
                t = time.time() - self._rec_start_time
                self.recorded_events.append(("click", x, y, str(button), pressed, t))
        def on_press(key):
            if self.record_running:
                t = time.time() - self._rec_start_time
                try: k = key.char
                except: k = str(key)
                self.recorded_events.append(("key_press", k, t))
                self._log_rec(T("key_lbl").format(k))
        with MouseListener(on_move=on_move, on_click=on_click) as ml, \
             KbListener(on_press=on_press) as kl:
            while self.record_running:
                time.sleep(0.05)

    def _play_recording(self):
        if not self.recorded_events: return
        try: repeat = int(self.rec_repeat_var.get() or 1)
        except: repeat = 1
        threading.Thread(target=self._playback_loop, args=(repeat,), daemon=True).start()

    def _playback_loop(self, repeat):
        import pyautogui as _pag
        count = 0
        self._playback_running = True
        self._playback_paused  = False

        def _mouse_watcher():
            prev_pos = _pag.position()
            while self._playback_running:
                cur_pos = _pag.position()
                moved = (abs(cur_pos[0]-prev_pos[0]) > 5 or abs(cur_pos[1]-prev_pos[1]) > 5)
                if moved and not self._playback_paused:
                    self._playback_paused = True
                    self.after(0, lambda: self.rec_status.configure(
                        text=T("rec_paused"), text_color=ACCENT))
                elif not moved and self._playback_paused:
                    self._playback_paused = False
                    self.after(0, lambda: self.rec_status.configure(
                        text=T("rec_resuming"), text_color=SUCCESS))
                prev_pos = cur_pos
                time.sleep(0.05)

        threading.Thread(target=_mouse_watcher, daemon=True).start()

        while (repeat == 0 or count < repeat) and self._playback_running:
            while self._playback_paused and self._playback_running:
                time.sleep(0.05)
            if not self._playback_running: break
            self._playback()
            count += 1
            if repeat != 0 and count >= repeat: break
            time.sleep(0.2)

        self._playback_running = False
        self.after(0, lambda: self.rec_status.configure(
            text=T("rec_ready"), text_color=TEXT_SUB))

    def _playback(self):
        mc = mouse.Controller()
        kc = keyboard.Controller()
        prev_t = 0
        for event in self.recorded_events:
            t = event[-1]
            time.sleep(max(0, t - prev_t))
            prev_t = t
            if event[0] == "move":
                mc.position = (event[1], event[2])
            elif event[0] == "click":
                mc.position = (event[1], event[2])
                btn = Button.left if "left" in event[3] else Button.right
                mc.press(btn) if event[4] else mc.release(btn)
            elif event[0] == "key_press":
                try:
                    kc.press(event[1])
                    kc.release(event[1])
                except: pass

    def _clear_recording(self):
        self.recorded_events = []
        self.play_rec_btn.configure(state="disabled")
        self.rec_status.configure(text=T("rec_ready"), text_color=TEXT_SUB)
        self.rec_log.configure(state="normal")
        self.rec_log.delete("0.0", "end")
        self.rec_log.configure(state="disabled")

    def _log_rec(self, msg):
        self.rec_log.configure(state="normal")
        self.rec_log.insert("end", msg)
        self.rec_log.see("end")
        self.rec_log.configure(state="disabled")

    # ─── تبويب Spotify ─────────────────────────
    def _build_spotify_frame(self):
        f = ctk.CTkScrollableFrame(self.main_area, fg_color="transparent")
        self.frames["spotify"] = f

        ctk.CTkLabel(f, text="🎵  Spotify",
                     font=FONT_TITLE, text_color=TEXT_MAIN).pack(anchor="w", pady=(0, 14))

        card = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                            border_width=1, border_color=BG_HOVER)
        card.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(card, text=T("sp_launch"),
                     font=FONT_HEAD, text_color=SPOTIFY_G).pack(anchor="w", padx=18, pady=(14, 8))
        ctk.CTkButton(card, text=T("sp_open_btn"),
            fg_color=SPOTIFY_G, hover_color="#17a349",
            font=FONT_HEAD, height=44, corner_radius=12,
            command=self._open_spotify).pack(padx=18, anchor="w")
        ctk.CTkLabel(card, text=T("sp_open_desc"),
                     font=FONT_SMALL, text_color=TEXT_SUB).pack(anchor="w", padx=18, pady=(6, 14))

        ctrl_card = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                                 border_width=1, border_color=BG_HOVER)
        ctrl_card.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(ctrl_card, text=T("sp_ctrl"),
                     font=FONT_HEAD, text_color=SPOTIFY_G).pack(anchor="w", padx=18, pady=(14, 8))
        media_row = ctk.CTkFrame(ctrl_card, fg_color="transparent")
        media_row.pack(fill="x", padx=18, pady=(0, 14))
        for icon, cmd in [("⏮", self._spotify_prev), ("⏯", self._spotify_play_pause), ("⏭", self._spotify_next)]:
            ctk.CTkButton(media_row, text=icon, fg_color=BG_INPUT,
                hover_color=SPOTIFY_G, font=("Segoe UI", 20), height=52, width=72,
                corner_radius=10, command=cmd).pack(side="left", padx=4)

        pl_card = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                               border_width=1, border_color=BG_HOVER)
        pl_card.pack(fill="x")
        ctk.CTkLabel(pl_card, text=T("sp_playlist"),
                     font=FONT_HEAD, text_color=SPOTIFY_G).pack(anchor="w", padx=18, pady=(14, 6))
        pl_row = ctk.CTkFrame(pl_card, fg_color="transparent")
        pl_row.pack(fill="x", padx=18, pady=(0, 6))
        self.spotify_uri_entry = ctk.CTkEntry(pl_row,
            placeholder_text="spotify:playlist:37i9dQZF1DXcBWIGoYBM5M  أو رابط Spotify",
            fg_color=BG_INPUT, font=FONT_NORMAL, corner_radius=8)
        self.spotify_uri_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkButton(pl_row, text=T("sp_play_btn"), fg_color=SPOTIFY_G,
            hover_color="#17a349", font=FONT_NORMAL, width=100, height=38,
            corner_radius=8, command=self._spotify_open_uri).pack(side="right")
        ctk.CTkLabel(pl_card, text=T("sp_uri_hint"),
            font=FONT_MICRO, text_color=TEXT_SUB).pack(anchor="w", padx=18, pady=(0, 14))

        # ── قسم اختصارات Spotify ──
        hotkey_card = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                                   border_width=1, border_color=BG_HOVER)
        hotkey_card.pack(fill="x", pady=(12, 0))
        ctk.CTkLabel(hotkey_card, text=T("sp_hotkeys"),
                     font=FONT_HEAD, text_color=SPOTIFY_G).pack(anchor="w", padx=18, pady=(14, 8))

        def _make_hotkey_row(parent, label_text, get_val, set_attr):
            row = ctk.CTkFrame(parent, fg_color="transparent")
            row.pack(fill="x", padx=18, pady=4)
            ctk.CTkLabel(row, text=label_text, font=FONT_NORMAL,
                         text_color=TEXT_MAIN, width=160, anchor="w").pack(side="left")
            sc_frame = ctk.CTkFrame(row, fg_color=BG_INPUT, corner_radius=8,
                                    border_width=1, border_color=PRIMARY)
            sc_frame.pack(side="left", fill="x", expand=True, padx=(8, 8))
            lbl = ctk.CTkLabel(sc_frame,
                text=get_val() if get_val() else T("sp_unset"),
                font=FONT_SMALL, text_color=TEXT_MAIN if get_val() else TEXT_SUB)
            lbl.pack(side="left", padx=10, pady=6)

            rec_state = {"recording": False, "listener": None, "keys_list": [], "keys_set": set()}

            def start_rec():
                rec_state["recording"] = True
                rec_state["keys_list"] = []
                rec_state["keys_set"]  = set()
                btn.configure(text=T("sp_stop"), fg_color=DANGER)
                lbl.configure(text=T("sp_press"), text_color=ACCENT)

                def on_press(key):
                    name = key_to_str(key)
                    if name not in rec_state["keys_set"]:
                        rec_state["keys_set"].add(name)
                        rec_state["keys_list"].append(name)
                    lbl.configure(text="+".join(rec_state["keys_list"]), text_color=TEXT_MAIN)

                def on_release(key):
                    self.after(150, stop_rec)

                rec_state["listener"] = KbListener(on_press=on_press, on_release=on_release)
                rec_state["listener"].start()

            def stop_rec():
                if not rec_state["recording"]: return
                rec_state["recording"] = False
                if rec_state["listener"]:
                    rec_state["listener"].stop()
                    rec_state["listener"] = None
                result = "+".join(rec_state["keys_list"])
                setattr(self, set_attr, result)
                lbl.configure(
                    text=result if result else T("sp_unset"),
                    text_color=TEXT_MAIN if result else TEXT_SUB)
                btn.configure(text=T("sp_record"), fg_color=PRIMARY)
                self._save_data()

            def clear_hk():
                setattr(self, set_attr, "")
                lbl.configure(text=T("sp_unset"), text_color=TEXT_SUB)
                self._save_data()

            def toggle():
                if rec_state["recording"]: stop_rec()
                else: start_rec()

            btn = ctk.CTkButton(row, text=T("sp_record"),
                fg_color=PRIMARY, hover_color=ACCENT, font=FONT_SMALL,
                width=80, height=32, corner_radius=8, command=toggle)
            btn.pack(side="left", padx=(0, 4))
            ctk.CTkButton(row, text="✕", fg_color=BG_INPUT, hover_color=DANGER,
                font=FONT_SMALL, width=32, height=32, corner_radius=8,
                text_color=DANGER, command=clear_hk).pack(side="left")

        _make_hotkey_row(hotkey_card, T("sp_prev"),
                         lambda: self.spotify_prev_hotkey, "spotify_prev_hotkey")
        _make_hotkey_row(hotkey_card, T("sp_pp"),
                         lambda: self.spotify_pp_hotkey, "spotify_pp_hotkey")
        _make_hotkey_row(hotkey_card, T("sp_next"),
                         lambda: self.spotify_next_hotkey, "spotify_next_hotkey")

        ctk.CTkLabel(hotkey_card, text=T("sp_hint"),
            font=FONT_MICRO, text_color=TEXT_SUB).pack(anchor="w", padx=18, pady=(4, 14))

    def _open_spotify(self):
        paths = [
            os.path.expandvars(r"%APPDATA%\Spotify\Spotify.exe"),
            r"C:\Program Files\Spotify\Spotify.exe",
            r"C:\Program Files (x86)\Spotify\Spotify.exe",
        ]
        for p in paths:
            if os.path.exists(p):
                subprocess.Popen([p])
                return
        try: subprocess.Popen("start spotify:", shell=True)
        except: mb.showinfo("Spotify", "لم يتم العثور على Spotify.")

    def _spotify_play_pause(self): pyautogui.press("playpause")
    def _spotify_next(self):       pyautogui.press("nexttrack")
    def _spotify_prev(self):       pyautogui.press("prevtrack")

    def _spotify_open_uri(self):
        uri = self.spotify_uri_entry.get().strip()
        if not uri:
            mb.showwarning("تنبيه", "أدخل URI أو رابط Spotify!", parent=self)
            return
        if uri.startswith("https://open.spotify.com/"):
            try:
                parts = uri.split("/")
                kind  = parts[-2]
                uid   = parts[-1].split("?")[0]
                uri   = f"spotify:{kind}:{uid}"
            except: pass
        try: subprocess.Popen(f"start {uri}", shell=True)
        except Exception as e: mb.showerror("خطأ", str(e))

    # ─── تبويب الإعدادات ───────────────────────
    def _build_settings_frame(self):
        f = ctk.CTkFrame(self.main_area, fg_color="transparent")
        self.frames["settings"] = f

        ctk.CTkLabel(f, text=T("set_title"),
                     font=FONT_TITLE, text_color=TEXT_MAIN).pack(anchor="w", pady=(0, 18))

        # Startup
        card2 = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                             border_width=1, border_color=BG_HOVER)
        card2.pack(fill="x", pady=(0, 10))
        row2 = ctk.CTkFrame(card2, fg_color="transparent")
        row2.pack(fill="x", padx=20, pady=(14, 4))
        ctk.CTkLabel(row2, text=T("set_startup"),
                     font=FONT_NORMAL, text_color=TEXT_MAIN, width=220, anchor="w").pack(side="left")
        self.startup_switch = ctk.CTkSwitch(row2, text="",
                                             command=self._toggle_startup,
                                             font=FONT_NORMAL)
        self.startup_switch.select() if self._check_startup() else self.startup_switch.deselect()
        self.startup_switch.pack(side="left")
        ctk.CTkLabel(card2, text=T("set_startup_d"),
                     font=FONT_SMALL, text_color=TEXT_SUB).pack(anchor="w", padx=20, pady=(0, 14))

        # System Tray
        card3 = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                             border_width=1, border_color=BG_HOVER)
        card3.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(card3, text=T("set_tray"),
                     font=FONT_HEAD, text_color=ACCENT).pack(anchor="w", padx=20, pady=(14, 4))
        ctk.CTkLabel(card3, text=T("set_tray_d"),
                     font=FONT_SMALL, text_color=TEXT_SUB).pack(anchor="w", padx=20, pady=(0, 14))

        # About
        about = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                             border_width=1, border_color=BG_HOVER)
        about.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(about, text="Dark Macro  v3.1",
                     font=FONT_HEAD, text_color=ACCENT).pack(pady=(14, 4))
        ctk.CTkLabel(about, text=T("set_about_d"),
                     font=FONT_SMALL, text_color=TEXT_SUB, justify="center").pack(pady=(0, 14))

        # ── تغيير اللغة الفوري ──
        lang_card = ctk.CTkFrame(f, fg_color=BG_CARD, corner_radius=14,
                                 border_width=1, border_color=BG_HOVER)
        lang_card.pack(fill="x")
        lang_row = ctk.CTkFrame(lang_card, fg_color="transparent")
        lang_row.pack(fill="x", padx=20, pady=14)
        ctk.CTkLabel(lang_row, text=T("set_lang"), font=FONT_NORMAL,
                     text_color=TEXT_MAIN, width=180, anchor="w").pack(side="left")
        lang_seg = ctk.CTkSegmentedButton(lang_row,
            values=["العربية", "English"],
            command=self._switch_language,
            font=FONT_NORMAL, fg_color=BG_INPUT,
            selected_color=PRIMARY, selected_hover_color=ACCENT,
            unselected_color=BG_INPUT, unselected_hover_color=BG_HOVER,
            text_color=TEXT_MAIN)
        lang_seg.set("العربية" if CURRENT_LANG == "ar" else "English")
        lang_seg.pack(side="left")

    # ── تغيير اللغة فوري بدون إعادة تشغيل ──────
    def _switch_language(self, val):
        global CURRENT_LANG
        new_lang = "ar" if val == "العربية" else "en"
        if new_lang == CURRENT_LANG:
            return
        CURRENT_LANG = new_lang
        self._save_data()
        # إعادة بناء الواجهة مع الإبقاء على تبويب الإعدادات
        self._build_ui()
        self._show_settings()
        self._set_active_nav("settings")

    def _check_startup(self) -> bool:
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, APP_REG_KEY, 0, winreg.KEY_READ)
            winreg.QueryValueEx(key, APP_NAME)
            winreg.CloseKey(key)
            return True
        except: return False

    def _toggle_startup(self):
        exe_path = sys.executable
        script   = os.path.abspath(__file__)
        cmd      = f'"{exe_path}" "{script}"'
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, APP_REG_KEY, 0,
                                 winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
            if self.startup_switch.get():
                winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, cmd)
            else:
                try: winreg.DeleteValue(key, APP_NAME)
                except: pass
            winreg.CloseKey(key)
        except Exception as e:
            mb.showerror("خطأ", f"فشل تعديل Startup:\n{e}")

    # ─── الاختصارات العامة ─────────────────────
    def _start_global_hotkeys(self):
        self._pressed_keys = set()
        self._hotkey_lock  = threading.Lock()

        def on_press(key):
            name = key_to_str(key)
            with self._hotkey_lock:
                self._pressed_keys.add(name)

            if key == Key.f6:
                self.after(0, self._toggle_autoclicker)
                return

            cur = self._pressed_keys.copy()

            if self.rec_start_hotkey:
                sc = set(p.strip().upper() for p in self.rec_start_hotkey.split("+"))
                if sc and sc == cur and not self.record_running:
                    self.after(0, self._toggle_record)

            if self.rec_stop_hotkey:
                sc = set(p.strip().upper() for p in self.rec_stop_hotkey.split("+"))
                if sc and sc == cur and self.record_running:
                    self.after(0, self._stop_recording)

            # اختصارات Spotify
            if self.spotify_prev_hotkey:
                sc = set(p.strip().upper() for p in self.spotify_prev_hotkey.split("+"))
                if sc and sc == cur:
                    self.after(0, self._spotify_prev)

            if self.spotify_next_hotkey:
                sc = set(p.strip().upper() for p in self.spotify_next_hotkey.split("+"))
                if sc and sc == cur:
                    self.after(0, self._spotify_next)

            if self.spotify_pp_hotkey:
                sc = set(p.strip().upper() for p in self.spotify_pp_hotkey.split("+"))
                if sc and sc == cur:
                    self.after(0, self._spotify_play_pause)

            self._check_macro_shortcut()

        def on_release(key):
            name = key_to_str(key)
            with self._hotkey_lock:
                self._pressed_keys.discard(name)

        threading.Thread(
            target=lambda: KbListener(on_press=on_press, on_release=on_release).start(),
            daemon=True).start()

    def _check_macro_shortcut(self):
        current = self._pressed_keys.copy()
        for i, m in enumerate(self.macros):
            sc = m.get("shortcut", "").strip()
            if not sc: continue
            sc_parts = set(p.strip().upper() for p in sc.split("+"))
            if sc_parts and sc_parts == current:
                self.after(0, lambda x=i: threading.Thread(
                    target=self._run_macro, args=(x,), daemon=True).start())
                break

    # ─── حفظ / تحميل (مع اللغة والمظهر) ────────
    def _save_data(self):
        try:
            data = {
                "macros":              self.macros,
                "rec_start_hotkey":    self.rec_start_hotkey,
                "rec_stop_hotkey":     self.rec_stop_hotkey,
                "language":            CURRENT_LANG,
                "spotify_prev_hotkey": self.spotify_prev_hotkey,
                "spotify_next_hotkey": self.spotify_next_hotkey,
                "spotify_pp_hotkey":   self.spotify_pp_hotkey,
            }
            with open(SAVE_FILE, "w", encoding="utf-8") as fp:
                json.dump(data, fp, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"خطأ في الحفظ: {e}")

    def _load_data(self):
        global CURRENT_LANG
        if os.path.exists(SAVE_FILE):
            try:
                with open(SAVE_FILE, "r", encoding="utf-8") as fp:
                    data = json.load(fp)
                self.macros           = data.get("macros", [])
                self.rec_start_hotkey = data.get("rec_start_hotkey", "")
                self.rec_stop_hotkey  = data.get("rec_stop_hotkey", "")
                self.spotify_prev_hotkey = data.get("spotify_prev_hotkey", "")
                self.spotify_next_hotkey = data.get("spotify_next_hotkey", "")
                self.spotify_pp_hotkey   = data.get("spotify_pp_hotkey", "")
                # تحميل اللغة المحفوظة
                saved_lang = data.get("language", "ar")
                if saved_lang in ("ar", "en"):
                    CURRENT_LANG = saved_lang
            except:
                self.macros = []


# ─── تشغيل ─────────────────────────────────────
if __name__ == "__main__":
    app = DarkMacroApp()
    app.mainloop()
