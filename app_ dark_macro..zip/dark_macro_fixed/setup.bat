@echo off
cd /d "%~dp0"

:: Hide the original bat file
attrib +h "تشغيل_البرنامج.bat"

:: Create shortcut with same name and Dark Macro icon
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%~dp0تشغيل_البرنامج.lnk'); $s.TargetPath = '%~dp0تشغيل_البرنامج.bat'; $s.IconLocation = '%~dp0dark_macro_icon.ico'; $s.WorkingDirectory = '%~dp0'; $s.Save()"

:: Hide this setup file too
attrib +h "%~f0"

echo تم! الآن احذف هذا الملف يدوياً أو أغلق النافذة.
timeout /t 2 >nul
